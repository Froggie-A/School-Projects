README

The program asks the user for an input file. The file must be in the workspace. If the input file is not found, the program will ask if they want to continue. If the user indicates Y, then the program will keep asking for an input. If the user indicates N, then the program will terminate and throw a FileNotFoundException. If the user indicates anything other than Y or N the program will keep asking the user to input an answer. 

The program reads the input file, and makes Car objects. The program then puts the Car objects into an array then asks the user for an output file.

If the output file is not found, the program will ask if they want to continue. If the user indicates Y, then the program will keep asking for an output file. If the user indicates N, then the program will terminate and throw a FileNotFoundException. Once the output file is correct the program would print Car objects sorted based on the make and then year and the number of cars on the top of the screen. 

GitHub
https://github.com/Froggie-A/Projects.git